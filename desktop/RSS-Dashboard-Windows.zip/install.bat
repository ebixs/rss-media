@echo off
set "DIR=%LOCALAPPDATA%\RSS-Dashboard"
if not exist "%DIR%" mkdir "%DIR%"
copy /y "%~dp0dashboard.ico" "%DIR%\dashboard.ico" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\RSS Dashboard.lnk'); $s.TargetPath='explorer.exe'; $s.Arguments='https://claude.ai/artifact/RChwJvCx5EvDFzRNPku3eP'; $s.IconLocation=$env:LOCALAPPDATA+'\RSS-Dashboard\dashboard.ico,0'; $s.Description='RSS marketing dashboard'; $s.Save()"
echo.
echo RSS Dashboard shortcut was created on your Desktop.
pause
